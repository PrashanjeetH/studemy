<?php
	/******************** ABOUT ******************************
	MySQL2AppGini, m2a.php, a script to import a MySQL/MariaDB
	schema to AXP format for use with AppGini.
	(C) Copyright 2019, BigProf Software.
	https://bigprof.com/appgini/m2a
	**********************************************************/

	/******************** workflow ***************************/
	$db_credentials = get_db_credentials();

	$error = ''; $tables = array();
	$axp = import_db_to_axp($db_credentials, $error, $tables);
	if($axp === false) fail_and_die($error);

	store_and_present($axp, $tables);
	/******************** end of workflow ********************/



	function get_db_credentials() {
		$errors = array();
		if(empty($_REQUEST['dbServer'])) $errors['dbServer'] = true;
		if(empty($_REQUEST['dbUser'])) $errors['dbUser'] = true;
		if(empty($_REQUEST['dbName'])) $errors['dbName'] = true;
		if(empty($_REQUEST['dbPass'])) $_REQUEST['dbPass'] = '';

		if(count($errors) == 3) ask_for_credentials_and_die();
		if(count($errors)) ask_for_credentials_and_die($errors);

		return $_REQUEST;
	}

	function ask_for_credentials_and_die($errors = array()) {
		$https = !empty($_SERVER['HTTPS']);
		if(!$https) $surl = "https://{$_SERVER['SERVER_NAME']}{$_SERVER['REQUEST_URI']}";

		?>
			<h1>Import a MySQL database to AppGini</h1>
			<p>Use this tool to import the definition of your MySQL database as an AXP project file that can be opened in <a href="https://bigprof.com/appgini/">AppGini</a>.</p>

			<?php if(!$https) { ?>
				<div class="danger">
					This page is not served through a secure connection. It's dangerous to continue
					because your database credentials will be sent to the server unencrypted and
					could potentially be stolen.<br>
					Try <a href="<?php echo $surl; ?>">loading the secure version of this page</a> if your server supports it, or continue at your own risk.
				</div>
			<?php } ?>

			<form method="POST" action="<?php echo basename(__FILE__); ?>">
				<div>
					<label for="dbServer">Database server</label>
					<input type="text" name="dbServer" id="dbServer" value="localhost" autofocus="">
					<?php if(isset($errors['dbServer'])) { ?>
						<div class="danger" id="dbServer-error">Invalid database server provided.</div>
					<?php } ?>
				</div>
				<div>
					<label for="dbName">Database name</label>
					<input type="text" name="dbName" id="dbName">
					<?php if(isset($errors['dbName'])) { ?>
						<div class="danger" id="dbName-error">Invalid database name provided.</div>
					<?php } ?>
				</div>
				<div>
					<label for="dbUser">Database username</label>
					<input type="text" name="dbUser" id="dbUser">
					<?php if(isset($errors['dbUser'])) { ?>
						<div class="danger" id="dbUser-error">Invalid database username provided.</div>
					<?php } ?>
				</div>
				<div>
					<label for="dbPass">Database password</label>
					<input type="password" name="dbPass" id="dbPass">
					<?php if(isset($errors['dbPass'])) { ?>
						<div class="danger" id="dbPass-error">Invalid database password provided.</div>
					<?php } ?>
				</div>
				<div><button type="submit">Continue &#9654;</button></div>
			</form>

			<script>
				var inputs = ['dbServer', 'dbName', 'dbUser'];
				for(var i = 0; i < inputs.length; i++) {
					(function(e) {
						if(document.querySelector('#' + e + '-error') === null) return;
							
						document.querySelector('#' + e).addEventListener('keyup', function() {
							if(this.value.length > 0)
								document.querySelector('#' + e + '-error').classList.add('hidden');
						});
					})(inputs[i]);
				}
			</script>

			<?php echo copyright_footer(); ?>
			<?php echo css_styles(); ?>

		<?php
		exit;
	}

	function import_db_to_axp($db_credentials, &$error, &$tables) {
		$data_types = array(
			'tinyint' => 1,
			'smallint' => 2,
			'mediumint' => 3,
			'int' => 4,
			'bigint' => 5,
			'float' => 6,
			'double' => 7,
			'decimal' => 8,
			'date' => 9,
			'datetime' => 10,
			'timestamp' => 11,
			'time' => 12,
			'year' => 13,
			'char' => 14,
			'varchar' => 15,
			'tinyblob' => 16,
			'tinytext' => 17,
			'text' => 18,
			'blob' => 19,
			'mediumblob' => 20,
			'mediumtext' => 21,
			'longblob' => 22,
			'longtext' => 23
		);

		$membership_tables = array(
			'membership_users',
			'membership_groups',
			'membership_grouppermissions',
			'membership_userrecords',
			'membership_userpermissions',
			'membership_usersessions'
		);

		$dbName = $db_credentials['dbName'];
		$dbUser = $db_credentials['dbUser'];
		$dbPass = $db_credentials['dbPass'];
		$dbServer = $db_credentials['dbServer'];

		$link = @mysqli_connect($dbServer, $dbUser, $dbPass, $dbName);

		if(!$link){
			$error = "Error while connecting to the database server: " . mysqli_connect_error();
			return false;
		}

		$axp = "<database>";
		$axp .= "<databaseName>$dbName</databaseName>";
		
		if(!$res = @mysqli_query($link, "show tables")) {
			$error = "Error while listing tables of the database: " . mysqli_error($link);
			return false;
		}

		$tables = array();
		while($row = mysqli_fetch_row($res)) {
			$tableName = $row[0];

			// avoid importing membership tables
			if(in_array($tableName, $membership_tables)) continue;

			$axp .= "\n\n<table>";
			$axp .= "<name>$tableName</name>";
			$axp .= "<caption>" . ucfirst($tableName) . "</caption>";
			$axp .= "<detailViewLabel>Detail View</detailViewLabel>";
			if(!$res2 = mysqli_query($link, "SHOW FIELDS FROM `$tableName`")) {
				$error = "Error while listing fields of the table '$tableName': " . mysqli_error($link);
				return false;
			}

			$i = 0;
			while($row2 = mysqli_fetch_row($res2)) {
				// data type, length, precision
				$dt = explode(" ", $row2[1]);
				$dtType = $dt[0];
				if(!isset($dt[1])) $dt[1] = '';
				if(!isset($dt[2])) $dt[2] = '';
				$dtLength = '';
				$dtPrecision = '';
				if(strpos($dt[0], "(") !== false) {
					$dtType = substr($dt[0], 0, strpos($dt[0], "("));
					$strSize = strstr($dt[0], "(");
					$strSize = str_replace(")", "", $strSize);
					$strSize = str_replace("(", "", $strSize);
					if(strpos($strSize, ',')) {
						list($dtLength, $dtPrecision) = explode(',', $strSize);
					} else {
						$dtLength = $strSize;
						$dtPrecision = '';
					}
				}
				
				// data type
				$dtType = $data_types[strtolower($dtType)];
				
				// unsigned
				$dtUnsigned = ($dt[1] == "unsigned" ? "True" : "False");
				
				// zerofill
				$dtZeroFill = ($dt[1] == "zerofill" || $dt[2] == "zerofill" ? "True" : "False");
				
				// binary
				$dtBinary = ($dt[1] == "binary" || $dt[2]=="binary" ? "True" : "False");
				
				// not null
				$notNull = ($row2[2] == '' ? "True" : "False");
				
				// pk
				$primaryKey = (strtoupper($row2[3]) == 'PRI' ? "True" : "False");
				
				// unique
				$unique = (strtoupper($row2[3]) == 'UNI' ? "True" : "False");
				
				// auto inc
				$autoIncrement = (strtolower($row2[5]) == 'auto_increment' ? "True" : "False");
				
				$axp .= "\n\t<field>";
				$axp .= "<caption>" . ucfirst($row2[0]) . "</caption>";
				$axp .= "<name>{$row2[0]}</name>";
				$axp .= "<dataType>$dtType</dataType>";
				$axp .= "<length>$dtLength</length>";
				$axp .= "<precision>$dtPrecision</precision>";
				$axp .= "<autoIncrement>$autoIncrement</autoIncrement>";
				$axp .= "<binary>$dtBinary</binary>";
				$axp .= "<notNull>$notNull</notNull>";
				$axp .= "<primaryKey>$primaryKey</primaryKey>";
				$axp .= "<unique>$unique</unique>";
				$axp .= "<unsigned>$dtUnsigned</unsigned>";
				$axp .= "<zeroFill>$dtZeroFill</zeroFill>";
				$axp .= "<default>$row2[4]</default>";
				$axp .= "<index>$i</index>";
				$axp .= "</field>";
				$i++;
			}
			$axp .= "\n\t</table>";
			$tables[] = $tableName;
		}
		
		$axp .= "</database>";

		return $axp;
	}
	
	function store_and_present($axp, $tables) {
		if(!@file_put_contents(dirname(__FILE__) . '/import.axp', $axp))
			die(
				"Couldn't save the project file. Please chmod the folder where you uploaded this script to 777 and try again."
			);

		?>
			<h1>MySQL2AppGini Database Import Wizard</h1>
		
			<p>Successufully imported the following tables:
				<ul class="tables-list"><li> <?php echo implode('</li><li> ', $tables); ?></li></ul>
			</p>
		
			<h3><a href="import.axp">Download the AppGini project file.</a></h3>
		
			<p><i><font color="darkblue">Right-click</font></i> the above link and select 'Save link as' or 'Save target as'.
			After downloading the file, you can double-click it to open in AppGini.</p>
			<button type="button" onclick="window.location='m2a.php';">Import another database</button>
		<?php
		echo copyright_footer();
		echo css_styles();
	}

	function fail_and_die($error) {
		?>
		<div class="danger"><?php echo $error; ?><button type="button" onclick="history.go(-1);">&#9664; Try again</button></div>
		<?php echo copyright_footer(); ?>
		<?php echo css_styles(); ?>
		<?php exit;
	}

	function copyright_footer() {
		ob_start(); ?>
		<div class="copyright">Copyright &copy; 2019, <a href="https://bigprof.com/appgini/m2a">BigProf Software</a>.</div>
		<?php return ob_get_clean();
	}

	function css_styles() {
		ob_start(); ?>
		<style>
			body {
				width: 100%;
				max-width: 40em;
				margin: 1.5em auto;
				font-family: sans-serif;
				line-height: 1.65em;
				padding-top: 97px;
				background-image: url("https://cdn.bigprof.com/appgini-new/logo.png");
				background-repeat: no-repeat;
				background-position-x: center;
				background-position-y: 27px;
			}
			.danger {
				color: red;
				background-color: #FFECEC;
				padding: 0.5em 1em;
				border: solid 1px red;
				margin-bottom: 1em;
			}
			label {
				display: block;
				font-weight: bold;
				margin-top: 1em;
			}
			input {
				width: 100%;
				font-size: 2em;
				font-family: monospace;
				color: #444;
			}
			input:focus {
				color: #000;
				border: solid 2px;
			}
			button {
				font-size: 1.25rem;
				font-weight: bold;
				margin: 1rem auto;
				display: block;
				min-width: 8rem;
				padding: 0.4rem 3rem;
			}
			ul.tables-list {
				max-height: 50vh;
				overflow-y: auto;
				border: dotted 1px #999;
				background-color: #f9f9f9;
				list-style: none;
			}
			ul.tables-list li:before {
				content: '\2714\0020';
			}
			.copyright {
				text-align: center;
				border-top: 1px solid #999;
				padding-top: 0.5rem;
				font-size: 0.8rem;
			}
			.hidden { display: none; }
		</style>
		<?php return ob_get_clean();
	}